#ifndef __STARC_H__
#define __STARC_H__

#include "ervp_matrix.h"
#include "ervp_mmiox1.h"
#include "starc_memorymap_offset.h"

typedef struct
{
  unsigned int bw_addr;
	unsigned int spikein_bw_data;
	unsigned int spikein_bw_tensor;
	unsigned int weight_bw_data;
	unsigned int weight_bw_tensor;
	unsigned int spikeout_bw_data;
	unsigned int spikeout_bw_tensor;
	unsigned int core_input_size;
	unsigned int core_output_size;
	unsigned int bw_weight;
	unsigned int bw_config;
	unsigned int bw_status;
	unsigned int bw_log;
	unsigned int bw_inst;
	unsigned int bw_input;
	unsigned int bw_output;
	unsigned int config_default_value; // invalid due to the limit of data type, but not used
	unsigned int log_fifo_depth;
	unsigned int inst_fifo_depth;
	unsigned int input_fifo_depth;
	unsigned int output_fifo_depth;
	unsigned int lsu_para;
} starc_hwpara_t;

typedef struct
{
  const ervp_mmiox1_hwinfo_t *mmiox_info;
  unsigned int core_input_size : 16;
  unsigned int core_output_size : 16;
  unsigned int bw_weight : 16;
	unsigned int capacitance : 16;
	int id : 16;
} starc_hwinfo_t;

void starc_hwinfo_elaborate(starc_hwpara_t *hwpara, starc_hwinfo_t *hwinfo);

typedef struct
{
	unsigned int num_spike_allowed : 16;
	unsigned int num_step_merged_m1 : 16;
	unsigned int neuron_reset_type : 8;
	unsigned int threshold : 16;
} ervp_starc_option_t;

static const int STARC_RESET = STARC_INST_OPCODE_CLEAR_CAP;
static const int STARC_LOAD_WEIGHT = STARC_INST_OPCODE_LOAD_WEIGHT;
static const int STARC_LAYER_STATIC = STARC_INST_OPCODE_EXEC_LAYER;
static const int STARC_LAYER_DYNAMIC = STARC_INST_OPCODE_LOAD_WEIGHT | STARC_INST_OPCODE_EXEC_LAYER;

void starc_inference_request(const starc_hwinfo_t* hwinfo, const ervp_starc_option_t* options, const ErvpMatrixInfo *spikein_info, const ErvpMatrixInfo *weight_info, ErvpMatrixInfo *spikeout_info);
static inline void starc_inference_wait(const starc_hwinfo_t *const hwinfo)
{
	mmiox1_inst_wait_busy(hwinfo->mmiox_info);
}

static inline void starc_inference(const starc_hwinfo_t* hwinfo, const ervp_starc_option_t* options, const ErvpMatrixInfo *spikein_info, const ErvpMatrixInfo *weight_info, ErvpMatrixInfo *spikeout_info)
{
    starc_inference_request(hwinfo,options,spikein_info,weight_info,spikeout_info);
    starc_inference_wait(hwinfo);
}

void starc_print_info(const starc_hwinfo_t* hwinfo);

#endif