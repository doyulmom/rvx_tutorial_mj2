#include "uthash.h"

#include "starc_support.h"
#include "ervp_malloc.h"
#include "ervp_bit_util.h"
#include "ervp_assert.h"
#include "ervp_matrix.h"
#include "ervp_matrix_element.h"

typedef struct convert_info
{
	const ErvpMatrixInfo *original;
	const ErvpMatrixInfo *converted;
	UT_hash_handle hh;
} convert_info_t;

typedef struct ip_convert_info
{
	const starc_hwinfo_t *hwinfo;
	convert_info_t *convert_dict;
	UT_hash_handle hh;
} ip_convert_info_t;

static ip_convert_info_t *ip_convert_dict = NULL;

static const ErvpMatrixInfo *convert_weight(const ErvpMatrixInfo *weight_info, int bw_weight)
{
	assert(!matrix_datatype_is_float(weight_info->datatype));
	ErvpMatrixInfo *converted = matrix_alloc(weight_info->datatype, weight_info->num_row, weight_info->num_col, NULL);
	int max_magnitude = generate_mask_by_size(bw_weight - 1);
	for (int i = 0; i < weight_info->num_row; i++)
	{
		for (int j = 0; j < weight_info->num_col; j++)
		{
			UNKNOWN_TYPE data = _matrix_read_element(weight_info, i, j);
			data.value_unsigned = convert_sign_and_magnitude(data.value_signed, bw_weight);
			_matrix_write_element(converted, i, j, data);
		}
	}
	return converted;
}

const ErvpMatrixInfo *starc_convert_weight(const starc_hwinfo_t *hwinfo, const ErvpMatrixInfo *weight_info)
{
	ip_convert_info_t *ip_convert_info;
	convert_info_t *convert_info;
	const ErvpMatrixInfo *result;
	HASH_FIND_INT(ip_convert_dict, &hwinfo, ip_convert_info);
	if (ip_convert_info == NULL)
	{
		ip_convert_info = malloc(sizeof(ip_convert_info_t));
		assert(ip_convert_info);
		ip_convert_info->hwinfo = hwinfo;
		ip_convert_info->convert_dict = NULL;
		HASH_ADD_INT(ip_convert_dict, hwinfo, ip_convert_info);
	}
	HASH_FIND_INT(ip_convert_info->convert_dict, &weight_info, convert_info);
	// printf("\n\n%p", ip_convert_info);
	// printf("\n%p", convert_info);
	if (convert_info == NULL)
	{
		convert_info = malloc(sizeof(convert_info_t));
		assert(convert_info);
		convert_info->original = weight_info;
		convert_info->converted = convert_weight(weight_info, hwinfo->bw_weight);
		HASH_ADD_INT(ip_convert_info->convert_dict, original, convert_info);
		result = convert_info->converted;

		convert_info = malloc(sizeof(convert_info_t));
		assert(convert_info);
		convert_info->original = result;
		convert_info->converted = NULL;
		HASH_ADD_INT(ip_convert_info->convert_dict, original, convert_info);
	}
	else
	{
		if (convert_info->converted == NULL)
			result = weight_info;
		else
			result = convert_info->converted;
	}
	return result;
}

unsigned int starc_analyze_num_spike_allowed(const starc_hwinfo_t* hwinfo, const ErvpMatrixInfo *weight_info, const ervp_starc_option_t* options)
{
	unsigned int result = hwinfo->core_input_size;
	if(options!=NULL)
		if(options->num_spike_allowed!=0)
			result = options->num_spike_allowed;
	return result;
}