#ifndef __SPI_CAM_H__
#define __SPI_CAM_H__

void spi_cam_check_test_reg(void);
void spi_cam_test(void);
void spi_cam_disp_test(void);

#endif
